# Seed-quality-classification-
A Python-based project for classifying plant seed quality using machine learning.
